<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Financial System</title>
    
    <link rel="stylesheet" href="style.css">
    
    <link rel="stylesheet" href="register.css">
</head>
<body class="login-body">

    <div class="login-box">
        <form action="auth.php" method="POST" id="regForm">
            <h2>Create Account</h2>
            <p style="font-size: 0.9em; color: #666; margin-bottom: 25px;">For new employees registration.</p>

            <?php if(isset($_GET['error'])): ?>
                <div class="alert">
                    <?php 
                        if($_GET['error'] == 'exists') echo "Email address is already in use.";
                        elseif($_GET['error'] == 'mismatch') echo "Passwords do not match.";
                        elseif($_GET['error'] == 'invalid_name') echo "Full Name cannot contain numbers.";
                        elseif($_GET['error'] == 'invalid_email') echo "Please use a valid @gmail.com address.";
                        else echo "An error occurred during registration.";
                    ?>
                </div>
            <?php endif; ?>

            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="fullname" id="fullname" placeholder="John Doe" required oninput="validateName(this)">
            </div>
            
            <div class="input-group">
                <label>Gmail Address (Username)</label>
                <input type="email" name="new_username" id="email" placeholder="example@gmail.com" required oninput="validateEmail(this)">
            </div>

            <div class="input-group">
                <label>Choose Password</label>
                <input type="password" name="new_password" id="new_password" placeholder="Min. 6 characters" required oninput="validatePassword()">
                <span class="toggle-password" onclick="togglePass('new_password', this)">Show</span>
            </div>

            <div class="input-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" id="confirm_password" placeholder="Repeat password" required oninput="validatePassword()">
                <span class="toggle-password" onclick="togglePass('confirm_password', this)">Show</span>
            </div>
            
            <button type="submit" name="register">Register Account</button>

            <p style="margin-top: 20px; text-align: center; font-size: 0.9em;">
                Already have an account? <a href="login.php" style="color: #1abc9c; text-decoration: none; font-weight: bold;">Login here</a>
            </p>
        </form>
    </div>

    <script>

        function togglePass(id, btn) {
            var x = document.getElementById(id);
            if (x.type === "password") {
                x.type = "text";
                btn.innerHTML = "Hide";
            } else {
                x.type = "password";
                btn.innerHTML = "Show";
            }
        }

        function validateName(input) {
            const regex = /^[a-zA-Z\s]*$/;
            if (input.value.length > 2 && regex.test(input.value)) {
                input.className = 'input-valid';
            } else {
                input.className = 'input-invalid';
            }
        }

        function validateEmail(input) {
            if (input.value.toLowerCase().endsWith('@gmail.com')) {
                input.className = 'input-valid';
            } else {
                input.className = 'input-invalid';
            }
        }

        function validatePassword() {
            const pass = document.getElementById('new_password');
            const confirm = document.getElementById('confirm_password');
            
            pass.className = (pass.value.length >= 6) ? 'input-valid' : 'input-invalid';

            if (confirm.value.length > 0) {
                confirm.className = (pass.value === confirm.value && pass.value.length >= 6) ? 'input-valid' : 'input-invalid';
            }
        }
    </script>
</body>
</html>