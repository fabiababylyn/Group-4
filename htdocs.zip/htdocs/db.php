<?php

$host = "sql100.infinityfree.com"; 
$dbname = "if0_41734311_financial_db";    
$username = "if0_41734311";      
$password = "denmark3001";        

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    
    die("Connection failed: " . $e->getMessage());
}
?>